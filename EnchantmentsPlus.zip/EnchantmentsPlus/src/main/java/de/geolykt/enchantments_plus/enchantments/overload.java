/*
 * This file is part of EnchantmentsPlus, a bukkit plugin.
 * Copyright (c) 2015 - 2020 Zedly and Zenchantments contributors.
 * Copyright (c) 2020 - 2021 Geolykt and EnchantmentsPlus contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package de.geolykt.enchantments_plus.enchantments;

import org.bukkit.entity.Player;

import de.geolykt.enchantments_plus.CustomEnchantment;
import de.geolykt.enchantments_plus.enums.BaseEnchantments;
import de.geolykt.enchantments_plus.enums.Hand;
import de.geolykt.enchantments_plus.util.Tool;
import de.geolykt.enchantments_plus.util.Utilities;

import static org.bukkit.potion.PotionEffectType.HEALTH_BOOST;

public class Overload extends CustomEnchantment {

    public static final int ID = 68;

    @Override
    public Builder<Overload> defaults() {
        return new Builder<>(Overload::new, ID)
            .all("Gives the player increased maximum HP",
                    new Tool[]{Tool.CHESTPLATE},
                    "Overload",
                    4, // MAX LVL
                    Hand.NONE,
                    BaseEnchantments.OVERLOAD);
    }

    public Overload() {
        super(BaseEnchantments.OVERLOAD);
    }

    //Adds mining fatigue, strength and slowness to the player
    @Override
    public boolean onScan(Player player, int level, boolean usedHand) {
        Utilities.addPotionNonflicker(player, HEALTH_BOOST, 610, (int) Math.round(level * power));
        return true;
    }
}
