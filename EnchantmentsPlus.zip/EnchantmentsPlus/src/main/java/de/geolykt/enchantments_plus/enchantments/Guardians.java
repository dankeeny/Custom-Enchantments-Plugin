/*
 * This file is part of EnchantmentsPlus, a bukkit plugin.
 * Copyright (c) 2015 - 2020 Zedly and Zenchantments contributors.
 * Copyright (c) 2020 - 2021 Geolykt and EnchantmentsPlus contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package de.geolykt.enchantments_plus.enchantments;

import org.bukkit.entity.Player;

import de.geolykt.enchantments_plus.CustomEnchantment;
import de.geolykt.enchantments_plus.enums.BaseEnchantments;
import de.geolykt.enchantments_plus.enums.Hand;
import de.geolykt.enchantments_plus.util.Tool;
import de.geolykt.enchantments_plus.util.Utilities;

import java.util.Random;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.Player;

public class Guardians extends CustomEnchantment {

    public static final int ID = 68;

    @Override
    public Builder<Guardians> defaults() {
        return new Builder<>(Guardians::new, ID)
            .all("Gives the player strength at a cost",
                    new Tool[]{Tool.LEGGINGS},
                    "Guardians",
                    5, // MAX LVL
                    Hand.NONE,
                    BaseEnchantments.GUARDIANS);
    }

    public Guardians() {
        super(BaseEnchantments.GUARDIANS);
    }

    //On hit a player should have a 1% change * lvl to spawn in an iron golem
    @Override
    public boolean onScan(Player player, int level, boolean usedHand) {
    // Calculate the chance of spawning an Iron Golem based on the level
    double chance = level * 0.01; // 1% chance per level
    Random random = new Random();
    
    // Check if the random number generated is less than or equal to the chance
    if (random.nextDouble() <= chance) {
        // Get the player's location
        Location location = player.getLocation();
        World world = player.getWorld();
        
        // Spawn an Iron Golem at the player's location
        IronGolem ironGolem = (IronGolem) world.spawnEntity(location, EntityType.IRON_GOLEM);
        
        ironGolem.setCustomName("Guardian Golem");
        
        // Return true to indicate that the enchantment was successfully triggered
        return true;
    }
    
    // Return false if no Iron Golem was spawned
    return false;
}

}
